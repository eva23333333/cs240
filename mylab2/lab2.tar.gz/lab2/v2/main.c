// Use functions changeval1() and changeval2() to illustrate
// passing by value vs. reference. 

#include <stdio.h>
int *s;
void main()
{

void changeval1(int);
void changeval2(int );
void changeval3();

s = 6;

  changeval1(s);
  printf("%d\n",s);

  changeval2(s);
  printf("%d\n",s);
  
  changeval3();
  printf("%d\n",s);

}


void changeval1(int a)
{
  a = 3;
}


void changeval2(int a)
{
  a = 3;
}

void changeval3(){
s=3;
}
