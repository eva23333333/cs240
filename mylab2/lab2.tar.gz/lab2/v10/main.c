// Basic string processing.

#include <stdio.h>
#include <string.h>
int main()
{
int i;
char a[7]; 
char c[7]="abcdefg";
//strcpy(a[7],"1234");

  a[0] = 'A';
  a[1] = 'B';
  a[2] = 'C';
  a[3] = '\0';
  a[4] = 'E';
  a[5] = 'F';
  a[6] = '\0';

  printf("%s\n",a);
  strcpy(a,c);
  printf("%s\n",a);

}
