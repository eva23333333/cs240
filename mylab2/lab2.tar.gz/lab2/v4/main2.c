// Using pointers (i.e., variables that contain addresses) directly in
// a program.

#include <stdio.h>

int main()
{
int x;
int *y;
int **z;
int ***w;
  x = 6;
  printf("%d\n",x);
  printf("%p\n",&x);

  y = &x;
  printf("%d\n",*y);
  printf("%p\n",y);

  z=&y;
  printf("%d\n",**z);

  w=&z;
printf("%d\n",***w);
}
