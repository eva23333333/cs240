// Pointers and arrays

#include <stdio.h>
int a;
void main()
{
int *h;

  h=&a;
  *h = 100;
  *(h+1) = 200;
  *(h+2) = 300;


 
  printf("%d\n",*h);
  printf("%d\n",*(h+1));
  printf("%d\n",*(h+2));

}
