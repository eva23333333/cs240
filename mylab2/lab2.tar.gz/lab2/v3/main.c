// Another passing by reference exercise

#include <stdio.h>
#include "modval.c" 
void modval(int *);

int main()
{
int x;

  x = 6;
  printf("%d\n",x);
  printf("%p\n",&x);
  modval(&x);
  printf("%d\n",x);

}



