void modval(int *a)
{
  printf("%p\n",a);
  *a = 3;
}

