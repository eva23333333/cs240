// version 3 of z = x * y
// reads the numbers to be added from keyboad
// using the standard I/O library function scanf()
// and outputs the result on the terminal
// using printf()

#include <stdio.h>

void main()
{

int *x,*y;
int z;
int a,b;
x = &a, y = &b; 

// read input
  scanf("%d %d",x,y);
x = &a, y = &b; 
/* compute 
   multiplication */
 z = a*b;

// print result
  printf("%d times %d = %d\n", a, b, z);

}
