/* 	version 5 of z = x * y
	same as version 4 but uses separate
	function mult2() to perform multiplication */ 

#include <stdio.h>

 mult2(float, float,float*);

void main() 
{

float x, y, z;

// read input
  scanf("%f %f",&x,&y);

// compute addition
  mult2(x,y,&z);

// print result
  printf("result of %f * %f is %.2f\n", x, y, z);

}


/*	function mult2(a,b) takes two
	arguments of type float, multiplies them and
	returns the result to the calling
	function */

  mult2(float a, float b,float *c )
{

// multiply argument a with argument b
// and store the result in local variable c

*c=a*b;

  
}
